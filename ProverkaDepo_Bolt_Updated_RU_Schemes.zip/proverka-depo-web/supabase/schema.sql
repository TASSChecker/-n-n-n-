-- ProverkaDepo: Supabase schema. Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  surname text not null,
  first_name text not null,
  group_name text,
  email text,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  subject text not null check (subject in ('pte','isi','fz','rules','depo','general')),
  topic text not null default '',
  question text not null,
  options jsonb not null check (jsonb_typeof(options)='array' and jsonb_array_length(options)=4),
  correct_index integer not null check (correct_index between 0 and 3),
  explanation text not null default '',
  source text not null default '',
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  subject text not null check (subject in ('pte','isi','fz','rules','depo','general')),
  score integer not null check (score >= 0),
  total integer not null check (total > 0 and score <= total),
  attempt_no integer not null check (attempt_no between 1 and 3),
  created_at timestamptz not null default now()
);

-- Create a profile automatically after signup using metadata supplied by the registration form.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,surname,first_name,group_name,email)
  values(new.id,
    coalesce(new.raw_user_meta_data->>'surname',''),
    coalesce(new.raw_user_meta_data->>'first_name',''),
    nullif(new.raw_user_meta_data->>'group_name',''),
    new.email);
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- A student must not be able to promote themselves to administrator.
create or replace function public.prevent_role_change()
returns trigger language plpgsql as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null
     and not exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin') then
    raise exception 'Only an administrator can change roles';
  end if;
  return new;
end; $$;
drop trigger if exists protect_profile_role on public.profiles;
create trigger protect_profile_role before update on public.profiles
for each row execute procedure public.prevent_role_change();

-- Enforce maximum three attempts per student, per section, per database calendar day.
create or replace function public.enforce_daily_attempt_limit()
returns trigger language plpgsql security definer set search_path=public as $$
declare n integer;
begin
  if new.user_id <> auth.uid() then raise exception 'Cannot submit attempts for another user'; end if;
  perform pg_advisory_xact_lock(hashtext(new.user_id::text || new.subject || current_date::text));
  select count(*) into n from public.attempts
   where user_id=new.user_id and subject=new.subject
   and (created_at at time zone 'UTC')::date=(now() at time zone 'UTC')::date;
  if n >= 3 then raise exception 'Daily limit reached: maximum 3 attempts per section'; end if;
  new.attempt_no := n+1;
  return new;
end; $$;
drop trigger if exists attempts_daily_limit on public.attempts;
create trigger attempts_daily_limit before insert on public.attempts
for each row execute procedure public.enforce_daily_attempt_limit();

alter table public.profiles enable row level security;
alter table public.questions enable row level security;
alter table public.attempts enable row level security;

create policy "Profiles read self or admin" on public.profiles for select to authenticated
using (id=auth.uid() or exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'));
create policy "Students insert own profile" on public.profiles for insert to authenticated with check(id=auth.uid() and role='student');
create policy "Students update own details" on public.profiles for update to authenticated
using(id=auth.uid()) with check(id=auth.uid());

create policy "Authenticated read active questions" on public.questions for select to authenticated
using(is_active=true or exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'));
create policy "Admins add questions" on public.questions for insert to authenticated
with check(exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'));
create policy "Admins update questions" on public.questions for update to authenticated
using(exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'))
with check(exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'));
create policy "Admins delete questions" on public.questions for delete to authenticated
using(exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'));

create policy "Students read own attempts or admin reads all" on public.attempts for select to authenticated
using(user_id=auth.uid() or exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'));
create policy "Students insert own attempts" on public.attempts for insert to authenticated
with check(user_id=auth.uid());

-- Admin-only views used by the dashboard.
create or replace view public.admin_attempt_results as
select a.id,a.user_id,p.surname,p.first_name,p.group_name,a.subject,a.score,a.total,a.attempt_no,a.created_at
from public.attempts a join public.profiles p on p.id=a.user_id
where exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin');

create or replace view public.admin_student_list as
select p.id,p.surname,p.first_name,p.group_name,p.email
from public.profiles p
where exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin');

grant select on public.admin_attempt_results to authenticated;
grant select on public.admin_student_list to authenticated;

-- IMPORTANT: after creating your own account, promote it manually from SQL Editor:
-- update public.profiles set role='admin' where id=(select id from auth.users where email='YOUR_ADMIN_EMAIL');


-- Answer-level history powers the student's personal mistake-review page.
create table if not exists public.attempt_answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  subject text not null check (subject in ('pte','isi','fz','rules','depo','general')),
  question_id uuid references public.questions(id) on delete set null,
  question_text text not null,
  options jsonb not null,
  selected_index integer not null check (selected_index between 0 and 3),
  correct_index integer not null check (correct_index between 0 and 3),
  explanation text not null default '',
  created_at timestamptz not null default now()
);
alter table public.attempt_answers enable row level security;
drop policy if exists "Students read own answer history" on public.attempt_answers;
create policy "Students read own answer history" on public.attempt_answers
for select to authenticated using(user_id=auth.uid() or exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'));
drop policy if exists "Students insert own answer history" on public.attempt_answers;
create policy "Students insert own answer history" on public.attempt_answers
for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from public.attempts a where a.id=attempt_id and a.user_id=auth.uid()));
grant select,insert on public.attempt_answers to authenticated;

-- For projects created with an earlier schema, add the image field without data loss.
alter table public.questions add column if not exists image_url text;
